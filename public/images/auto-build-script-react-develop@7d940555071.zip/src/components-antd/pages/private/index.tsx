
function PrivatePage() {
    return (
        <div>PrivatePage</div>
    )
}

export default PrivatePage