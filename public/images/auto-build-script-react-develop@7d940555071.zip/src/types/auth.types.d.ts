export type AuthSession = {
  userId?: string;
  token?: string;
  refreshToken?: string;
};

