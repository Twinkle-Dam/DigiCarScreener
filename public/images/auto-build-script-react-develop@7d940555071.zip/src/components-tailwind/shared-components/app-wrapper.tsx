import { Suspense } from 'react';
import { Outlet } from 'react-router-dom';
import CircularCustomLoader from './loaders/circular-custom-loader';
import useGetResponsiveness from '@hooks/useGetResponsiveness';
import ExampleNavBar from './navbar-example';

function AppWrapper() {
  const { isMobile } = useGetResponsiveness();

  return (
    <Suspense fallback={<CircularCustomLoader />}>
      <div className="flex flex-col relative">
        <ExampleNavBar />
        <div
          className={`flex flex-col flex-grow gap-20 min-w-full min-h-full h-full ${isMobile ? 'mt-14' : 'mt-16'}`}
          style={{ padding: '0px' }}
        >
          <Outlet />
        </div>
      </div>
    </Suspense>
  );
}

export default AppWrapper;
