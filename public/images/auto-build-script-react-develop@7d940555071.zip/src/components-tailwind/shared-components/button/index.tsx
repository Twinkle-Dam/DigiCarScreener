import  {Button}  from "flowbite-react";

type ButtonPropsType = {
  className?: string;
  id?: string;
  type?: string;
  children?: any;
};

const ButtonComp = ({children, className, type = 'button', ...props}:ButtonPropsType) => {
  return (
    <Button type={type} className={`${className}`} {...props}>{children}</Button>
  )
}

export default ButtonComp