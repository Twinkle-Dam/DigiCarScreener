import { InputHTMLAttributes } from 'react';

interface InputWrapperProps extends InputHTMLAttributes<HTMLInputElement> {
    id?: string;
    status?: string;
    placeholder?: string;
}

function InputWrapper({ id, status, placeholder, ...props }: InputWrapperProps) {
    return (
        <input
            id={id}
            placeholder={placeholder}
            className={`w-full p-2 border ${status === 'error' ? 'border-red-500' : 'border-gray-300'} rounded`}
            {...props}
        />
    );
}

export default InputWrapper;
