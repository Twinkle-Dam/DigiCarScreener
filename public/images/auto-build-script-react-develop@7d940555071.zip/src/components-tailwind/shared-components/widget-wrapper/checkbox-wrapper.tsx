import { InputHTMLAttributes } from 'react';

interface CheckboxWrapperProps extends InputHTMLAttributes<HTMLInputElement> {
    id?: string;
    checked?: boolean;
    onChange?: (e: React.ChangeEvent<HTMLInputElement>) => void;
    children?: React.ReactNode;
}

function CheckboxWrapper({ id, checked, onChange, children, ...props }: CheckboxWrapperProps) {
    return (
        <label className="flex items-center space-x-2">
            <input
                type="checkbox"
                id={id}
                checked={checked}
                onChange={onChange}
                className="form-checkbox h-5 w-5 text-blue-600"
                {...props}
            />
            {children && <span>{children}</span>}
        </label>
    )
}

export default CheckboxWrapper;
