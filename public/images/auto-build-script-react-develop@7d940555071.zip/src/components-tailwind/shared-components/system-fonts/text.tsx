import React from 'react';
import {
  FontWeightType,
  IntentType,
  SysFontFamilyType,
  fontColorType,
  fontSizeDesktop,
  fontSizeMobile,
  fontSizeTab,
  fontWeightType,
} from './text-local-const';
import { CSSProperties } from 'react';
import useGetResponsiveness from '@hooks/useGetResponsiveness';

type SystemTextProps = {
  variant?: IntentType;
  fontWeight?: FontWeightType;
  fontFamily?: SysFontFamilyType;
  fontColor?:
    | 'light'
    | 'dark'
    | 'sys_gray'
    | 'sys_golden'
    | 'sys_success'
    | 'sys_danger';
  children?: React.ReactNode;
  className?: string;
};

export const SystemText: React.FC<SystemTextProps> = ({
  variant = 'h1',
  fontWeight = 'normal',
  fontFamily = 'Playfair Display',
  fontColor = 'dark',
  children,
  className = '',
}) => {
  const { isMobile, isTab } = useGetResponsiveness();

  let fontSizeClass = '';
  if (isMobile) {
    fontSizeClass = fontSizeMobile[variant];
  } else if (isTab) {
    fontSizeClass = fontSizeTab[variant];
  } else {
    fontSizeClass = fontSizeDesktop[variant];
  }

  const fontWeightClass = fontWeightType[fontWeight];

  const fontColorClass = fontColorType[fontColor];

  const combinedClasses = `font-${fontWeightClass} font-${fontFamily} text-${fontColorClass} ${fontSizeClass} ${className}`;

  return (
    <div className={combinedClasses}>
      {children}
    </div>
  );
};
