import React, { useEffect } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { RootState } from '../../../redux/store';
import { deleteToast } from '../../../redux/toast.slice';

const StatusAlert: React.FC = () => {
  const dispatch = useDispatch();
  const toasts = useSelector((state: RootState) => state.toasts.toasts);

  useEffect(() => {
    const handleClose = () => {
      if (toasts.length > 0) {
        dispatch(deleteToast(toasts[0].id));
      }
    };

    if (toasts.length > 0) {
      // Display toast notification
      console.log(`Toast: ${toasts[0]?.type} - ${toasts[0]?.message}`);

      const timerId = setTimeout(() => {
        handleClose();
      }, toasts[0].ttl || 5000);

      return () => clearTimeout(timerId);
    }
  }, [dispatch, toasts]);

  if (toasts.length === 0 || !toasts[0]?.message) {
    return null;
  }

  return (
    <div className="fixed bottom-4 right-4 z-50">
      <div className="bg-white rounded-md shadow-md p-4">
        <p className="font-medium">{toasts[0]?.message}</p>
      </div>
    </div>
  );
};

export default StatusAlert;
