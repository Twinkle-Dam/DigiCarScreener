import { Controller, Control, FieldValues, RegisterOptions } from 'react-hook-form'
import CheckboxWrapper from '@shared-components/widget-wrapper/checkbox-wrapper'

interface CheckboxControllerWrapperProps {
    formContext?: Control<any>,
    controlName?: string,
    controlId?: string,
    error?: boolean,
    placeHolder?: string
    label?: string
    errorMessage?: string
    controlValidationRules?: Omit<RegisterOptions<FieldValues, string>, "valueAsNumber" | "valueAsDate" | "setValueAs" | "disabled">
}

function CheckboxControllerWrapper({
    formContext,
    controlName = '',
    controlId,
    label,
    placeHolder,
    error,
    errorMessage,
    controlValidationRules
}: CheckboxControllerWrapperProps) {
    return (
        <div className="flex flex-col items-start w-full">
            {label && (
                <h5 className="text-lg font-medium">
                    {label}
                </h5>
            )}
            <Controller
                name={controlName}
                control={formContext}
                rules={controlValidationRules}
                render={({ field }) => (
                    <CheckboxWrapper
                        id={controlId}
                        checked={field.value}
                        onChange={field.onChange}
                    >
                        {placeHolder}
                    </CheckboxWrapper>
                )}
            />
            {error && (
                <p className="text-red-500">
                    {errorMessage}
                </p>
            )}
        </div>
    )
}

export default CheckboxControllerWrapper;
