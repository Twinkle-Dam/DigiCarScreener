import { Controller, Control, FieldValues, RegisterOptions } from 'react-hook-form';
import InputWrapper from '../widget-wrapper/input-wrapper';

interface InputControllerWrapperProps {
    formContext?: Control<any>,
    controlName?: string,
    controlId?: string,
    placeHolder?: string,
    label?: string,
    error?: boolean,
    errorMessage?: string,
    controlValidationRules?: Omit<RegisterOptions<FieldValues, string>, "valueAsNumber" | "valueAsDate" | "setValueAs" | "disabled">
}

function InputControllerWrapper({
    formContext,
    controlName = '',
    controlId,
    placeHolder,
    label,
    error,
    errorMessage,
    controlValidationRules
}: InputControllerWrapperProps) {
    return (
        <div className="flex flex-col items-start w-full">
            {label && (
                <h5 className="text-lg font-medium">
                    {label}
                </h5>
            )}
            <Controller
                name={controlName}
                control={formContext}
                rules={controlValidationRules}
                render={({ field }) => (
                    <InputWrapper
                        id={controlId}
                        placeholder={placeHolder}
                        status={error ? 'error' : ''}
                        {...field}
                    />
                )}
            />
            {error && (
                <p className="text-red-500">
                    {errorMessage}
                </p>
            )}
        </div>
    );
}

export default InputControllerWrapper;
