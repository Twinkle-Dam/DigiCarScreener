import { Accordion } from "flowbite-react";
import React from "react";

interface PanelProps {
  title: string;
  content: React.ReactNode;
}

interface AccordionCompProps {
  panels: PanelProps[];
}

const AccordionComp = (props: AccordionCompProps) => {
  return (
    <Accordion>
      {props.panels.map((panel, index) => (
        <Accordion.Panel key={index}>
          <Accordion.Title>{panel.title}</Accordion.Title>
          <Accordion.Content>{panel.content}</Accordion.Content>
        </Accordion.Panel>
      ))}
    </Accordion>
  );
};

export default AccordionComp;
