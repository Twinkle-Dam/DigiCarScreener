import React from 'react';
import { FieldErrors, FieldValues } from 'react-hook-form';

interface ErrorMessageProps {
  errors: FieldErrors<FieldValues>;
  name: string;
}

const ErrorMessage: React.FC<ErrorMessageProps> = ({ errors, name }) => {
  const error = errors[name];

  return error ? (
    <p className="text-red-500">
      {error.message?.toString()}
    </p>
  ) : null;
};

export default ErrorMessage;
