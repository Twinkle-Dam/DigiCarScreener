import React, { useState, useEffect, ReactNode } from 'react';
import { useDispatch } from 'react-redux';
import { setAuthenticatedUser, setLoadingAuthRdx } from '../../redux/auth/auth.slice';
import { useTranslation } from 'react-i18next';

// Import the Tailwind CSS spinner component
import CircularCustomLoader from './loaders/circular-custom-loader';

interface AuthProviderWrapperProps {
  children: ReactNode;
}

const AuthProviderWrapper: React.FC<AuthProviderWrapperProps> = ({ children }) => {
  const { ready } = useTranslation();
  const [loading, setLoading] = useState<boolean>(true);
  const dispatch = useDispatch();

  useEffect(() => {
    const fetchData = async () => {
      setLoading(true);
      dispatch(setLoadingAuthRdx({ loading: true }));
      // Simulate some async auth logic
      await new Promise(resolve => setTimeout(resolve, 2000)); // Simulating a delay
      dispatch(setAuthenticatedUser());
      setLoading(false);
    };

    fetchData();
  }, [dispatch]);

  if (loading || !ready) {
    return <CircularCustomLoader />;
  }

  return <>{children}</>;
};

export default AuthProviderWrapper;
