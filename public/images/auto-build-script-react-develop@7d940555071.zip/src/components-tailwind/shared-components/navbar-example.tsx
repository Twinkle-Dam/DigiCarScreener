import { useTranslation } from 'react-i18next';
import useNavigateToTop from '@hooks/useNavigateToTop';
import { RootState } from '@redux/store';
import { useDispatch, useSelector } from 'react-redux';
import { logOutUser } from '@redux/auth/auth.slice';

export default function ExampleNavBar() {
  const { i18n, t } = useTranslation();
  const dispatch = useDispatch();
  const { goto } = useNavigateToTop();
  const isLoggedIn = useSelector(
    (state: RootState) => state.auth.isAuthenticated
  );

  const handleLogoutUser = () => {
    dispatch(logOutUser());
    goto('/login');
  };

  const changeLanguage = (language: 'en' | 'fr') => {
    i18n.changeLanguage(language);
  };

  return (
    <div className="fixed top-0 w-full bg-black p-4">
      <div className="flex justify-between items-center">
        <h6 className="text-white flex-grow">{t('example_navbar')}</h6>
        <div className="space-x-4">
          <button className="text-white" onClick={() => changeLanguage('en')}>EN</button>
          <button className="text-white" onClick={() => changeLanguage('fr')}>FR</button>
          {isLoggedIn ?
            <button className="text-white" onClick={() => handleLogoutUser()}>Logout</button>
            :
            <>
              <button className="text-white" onClick={() => goto('/login')}>Login</button>
              <button className="text-white" onClick={() => goto('/signup')}>Signup</button>
            </>
          }
        </div>
      </div>
    </div>
  );
}
