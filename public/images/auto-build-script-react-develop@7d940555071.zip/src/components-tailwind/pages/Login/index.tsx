import React from 'react';
import { useForm } from 'react-hook-form';
import { useLogin } from '@apis/useLogin';
import InputControllerWrapper from '@shared-components/controller-wrapper/input-controller-wrapper';
import Button from '@shared-components/button/index';

interface IFormInput {
  email: string;
  password: string;
}

const Login: React.FC = () => {
  const {
    handleSubmit,
    formState: { errors },
    control
  } = useForm<IFormInput>();
  const { mutate: login } = useLogin();

  const onSubmit = (data: IFormInput) => {
    console.log(data, "data");

    login({
      email: data.email,
      password: data.password,
    });
  };

  return (
    <div className="flex flex-col items-center justify-center min-h-screen bg-gray-800">
      <h4 className="text-white text-2xl mb-4">Login</h4>
      <form
        onSubmit={handleSubmit(onSubmit)}
        className="bg-gray-900 p-6 rounded-lg shadow-lg w-1/3"
      >
        <InputControllerWrapper
          label='Email'
          placeHolder='Email'
          formContext={control}
          controlId='email'
          controlName='email'
          controlValidationRules={{
            required: 'Email is required',
            pattern: {
              value: /^[^\s@]+@[^\s@]+\.[^\s@]+$/,
              message: 'Enter a valid email address',
            },
          }}
          error={!!errors?.email}
          errorMessage={errors?.email?.message || ''}
        />
        <InputControllerWrapper
          label='Password'
          placeHolder='Password'
          formContext={control}
          controlId='password'
          controlName='password'
          controlValidationRules={{
            required: 'Password is required',
            minLength: {
              value: 6,
              message: 'Password must be at least 6 characters',
            },
          }}
          error={!!errors?.password}
          errorMessage={errors?.password?.message || ''}
        />
        <Button
          type="submit"
          className="bg-gray-600 text-white py-2 px-4 mt-3 rounded hover:bg-gray-700"
        >
          Login
        </Button>
      </form>
    </div>
  );
};

export default Login;

