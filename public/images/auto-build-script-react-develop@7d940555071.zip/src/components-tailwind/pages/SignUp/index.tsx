import React from 'react';
import { useForm, SubmitHandler } from 'react-hook-form';
import { useSignup } from '@apis/useSignup';
import CheckboxControllerWrapper from '@shared-components/controller-wrapper/checkbox-controller-wrapper';
import InputControllerWrapper from '@shared-components/controller-wrapper/input-controller-wrapper';
import Button from '@shared-components/button/index';

interface IFormInput {
  name: string;
  email: string;
  password: string;
  confirmPassword: string;
  avatar: string;
  terms: boolean;
}

const Signup: React.FC = () => {
  const {
    handleSubmit,
    watch,
    formState: { errors },
    control
  } = useForm<IFormInput>();
  const { mutate: signup, isLoading } = useSignup();

  const onSubmit: SubmitHandler<IFormInput> = data => {
    signup({
      name: data.name,
      email: data.email,
      password: data.password,
      avatar: data.avatar,
    });
  };

  const password = watch('password', '');

  return (
    <div className="flex flex-col items-center justify-center min-h-screen bg-gray-800">
      <h4 className="text-white text-2xl mb-4">Sign Up</h4>
      <form
        onSubmit={handleSubmit(onSubmit)}
        className="bg-gray-900 p-6 rounded-lg shadow-lg w-1/3"
      >
        <InputControllerWrapper
          controlId="name"
          controlName="name"
          formContext={control}
          controlValidationRules={{
            required: 'Name is required',
          }}
          label='Name'
          placeHolder='Name'
          error={!!errors?.name}
          errorMessage={errors?.name?.message}
        />
        <InputControllerWrapper
          controlId="email"
          controlName="email"
          formContext={control}
          controlValidationRules={{
            required: 'Email is required',
            pattern: {
              value: /^[^\s@]+@[^\s@]+\.[^\s@]+$/,
              message: 'Enter a valid email address',
            },
          }}
          label='User Email'
          placeHolder='User Email'
          error={!!errors?.email}
          errorMessage={errors?.email?.message}
        />
        <InputControllerWrapper
          controlId="password"
          controlName="password"
          formContext={control}
          controlValidationRules={{
            required: 'Password is required',
            minLength: {
              value: 6,
              message: 'Password must be at least 6 characters',
            },
          }}
          label='Password'
          placeHolder='Password'
          error={!!errors?.password}
          errorMessage={errors?.password?.message}
        />
        <InputControllerWrapper
          controlName="confirmPassword"
          controlId="confirmPassword"
          formContext={control}
          controlValidationRules={{
            required: 'Confirm Password is required',
            validate: value => value === password || 'Passwords do not match',
          }}
          label='Confirm Password'
          placeHolder='Confirm Password'
          error={!!errors?.confirmPassword}
          errorMessage={errors?.confirmPassword?.message}
        />
        <InputControllerWrapper
          controlName="avatar"
          controlId="avatar"
          formContext={control}
          controlValidationRules={{
            required: 'Avatar URL is required',
            pattern: {
              value: /^(ftp|http|https):\/\/[^ "]+$/,
              message: 'Enter a valid URL',
            },
          }}
          placeHolder='Avatar URL'
          label='Avatar URL'
          error={!!errors?.avatar}
          errorMessage={errors?.avatar?.message}
        />
        <CheckboxControllerWrapper
          controlName="terms"
          formContext={control}
          controlValidationRules={{
            required: 'You must accept the terms and conditions',
          }}
          placeHolder='I accept the terms and conditions'
          error={!!errors?.terms}
          errorMessage={errors?.terms?.message}
        />
        <Button
          className="bg-gray-600 text-white py-2 px-4 mt-3 rounded hover:bg-gray-700"
          disabled={isLoading}
          type="submit"
        >
          {isLoading ? 'Signing Up...' : 'Sign Up'}
        </Button>
      </form>
    </div>
  );
};

export default Signup;
