import { useMemo } from 'react';

function useGetResponsiveness() {
    const isMobile = useMemo(() => window.innerWidth < 640, []);
    const isTab = useMemo(() => window.innerWidth >= 640 && window.innerWidth < 1024, []);
    const isLowResDesktop = useMemo(() => window.innerWidth >= 1024 && window.innerWidth < 1280, []);
    const isHighResDesktop = useMemo(() => window.innerWidth >= 1280, []);

    return { isMobile, isTab, isLowResDesktop, isHighResDesktop };
}

export default useGetResponsiveness;

