import React from 'react';
import { useForm } from 'react-hook-form';
import Typography from '@mui/material/Typography';
import { useLogin } from '@apis/useLogin';
import InputControllerWrapper from '@shared-components/controller-wrapper/input-controller-wrapper';
import { FormContainer, FormBox, SubmitButton } from '../../../styles/styles.ts';

interface IFormInput {
  email: string;
  password: string;
}

const Login: React.FC = () => {
  const {
    control,
    handleSubmit,
    formState: { errors },
  } = useForm<IFormInput>();
  const { mutate: login } = useLogin();

  const onSubmit = (data: IFormInput) => {
    login({
      email: data.email,
      password: data.password,
    });
  };

  return (
    <FormContainer>
      <Typography variant="h4" component="h1" gutterBottom>
        Login
      </Typography>
      <FormBox onSubmit={handleSubmit(onSubmit)} noValidate>
        <InputControllerWrapper
          label='Email'
          placeHolder='Email'
          formContext={control}
          controlId='email'
          controlName='email'
          controlValidationRules={{
            required: 'Email is required',
            pattern: {
              value: /^[^\s@]+@[^\s@]+\.[^\s@]+$/,
              message: 'Enter a valid email address',
            },
          }}
          error={!!errors?.email}
          errorMessage={errors?.email?.message || ''}
        />
        <InputControllerWrapper
          label='Password'
          placeHolder='Password'
          formContext={control}
          controlId='password'
          controlName='password'
          controlValidationRules={{
            required: 'Password is required',
            minLength: {
              value: 6,
              message: 'Password must be at least 6 characters',
            }
          }}
          error={!!errors?.password}
          errorMessage={errors?.password?.message || ''}
        />
        <SubmitButton type="submit" fullWidth variant="contained">
          Login
        </SubmitButton>
      </FormBox>
    </FormContainer>
  );
};

export default Login;
