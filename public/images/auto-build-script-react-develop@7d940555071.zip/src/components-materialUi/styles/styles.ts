import styled from '@emotion/styled';
import Button from '@mui/material/Button';
import { Box, CircularProgress, Container, Grid, Skeleton, Typography } from '@mui/material';


export const FormContainer = styled('div')({
  display: 'flex',
  flexDirection: 'column',
  alignItems: 'center',
  color: 'black',
  width: '50%',
  padding:3
});

export const FormBox = styled('form')({
  marginTop: '1rem',
});

export const SubmitButton = styled(Button)({
  marginTop: '1.5rem',
  marginBottom: '1rem',
  backgroundColor: 'grey',
  color: 'white',
});


export const Wrapper = styled.div`
  display: flex;
  flex-direction: column;
  align-items: start;
  width: 100%;
`;

export const Label = styled(Typography)`
  && {
    font-size: 14px;
    margin-bottom: 8px;
  }
`;

export const ErrorMessage = styled(Typography)`
  && {
    font-size: 14px;
    color: red;
    margin-top: 4px;
  }
`;

export const CustomCircularProgress = styled(CircularProgress)({
  width: 'auto !important',
  height: '100% !important',
  minHeight: '20px',
  minWidth: '20px',
  color: '#171A1D',
});

export const LoaderWrapper = styled.div`
  display: flex;
  justify-content: center;
`;

export const StyledBox = styled(Box)`
  width: 100%;
  margin: 8px; /* Assuming 8px is equivalent to theme.spacing(1) */
`;

export const StyleBox = styled(Box)`
  flex-grow: 1;
`;

export const StyledGridContainer = styled(Grid)<{ isXSmall: boolean }>`
  ${({ isXSmall }) => `
    padding-left: ${isXSmall ? '16px' : '32px'}; /* Assuming 16px is equivalent to theme.spacing(2) and 32px is equivalent to theme.spacing(4) */
    padding-right: ${isXSmall ? '16px' : '32px'};
  `}
`;

export const StyledSkeleton = styled(Skeleton)`
  margin-top: 16px;
  margin-bottom: 16px; 
  `;

  export const AppMainWrapperDiv = styled('div')({
    display: 'flex',
    flexDirection: 'column',
    position: 'relative',
  });

  export const AppContainer = styled(Container)<{ isMobile: boolean }>`
  padding: 0px;
  min-width: 100%;
  min-height: 100%;
  margin-top: ${({ isMobile }) => (isMobile ? '56px' : '64px')};
  flex-grow: 1;
  display: flex;
  justify-content: center;
`;

export const ErrorSection = styled.section`
  display: flex;
  flex-direction: column;
  gap: 20px;
  justify-content: center;
  align-items: center;
`;
