import { Suspense } from 'react';
import CircularProgress from '@mui/material/CircularProgress';
import { Outlet } from 'react-router-dom';
import ExampleNavBar from './navbar-example';
import useGetResponsiveness from '@hooks/useGetResponsiveness';
import {AppContainer, AppMainWrapperDiv} from '../../styles/styles'
//  Example of styled components


function AppWrapper() {
  const { isMobile } = useGetResponsiveness()

  return (
    <Suspense fallback={<CircularProgress />}>
      <AppMainWrapperDiv>
        <ExampleNavBar />
        <AppContainer isMobile={isMobile}>
          <Outlet />
        </AppContainer>
      </AppMainWrapperDiv>
    </Suspense>
  );
}

export default AppWrapper;
