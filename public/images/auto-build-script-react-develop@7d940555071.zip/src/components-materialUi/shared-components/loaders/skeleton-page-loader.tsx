import { useTheme } from '@mui/material/styles';
import useMediaQuery from '@mui/material/useMediaQuery';
import Skeleton from '@mui/material/Skeleton';
import Grid from '@mui/material/Grid';
import {
  StyledBox,
  StyleBox,
  StyledGridContainer,
  StyledSkeleton
} from '../../../styles/styles.ts';

const FullPageSkeletonLoader = () => {
  const theme = useTheme();
  const isXSmall = useMediaQuery(theme.breakpoints.down('xs'));

  return (
    <StyleBox>
      {/* Header (Navbar) Skeleton */}
      <Skeleton variant='rectangular' height={56} />

      {/* Hero Section Skeleton */}
      <StyledSkeleton
        variant='rectangular'
        height={isXSmall ? 150 : 250}
      />

      {/* Main Content Area - Video Thumbnails */}
      <StyledGridContainer container spacing={2} isXSmall={isXSmall}>
        {Array.from(new Array(8)).map((_, index) => (
          <Grid item xs={6} sm={4} md={3} key={index}>
            <Skeleton variant='rectangular' height={180} />
            <Skeleton />
            <Skeleton width='60%' />
          </Grid>
        ))}
      </StyledGridContainer>
    </StyleBox>
  );
};

export default FullPageSkeletonLoader;
