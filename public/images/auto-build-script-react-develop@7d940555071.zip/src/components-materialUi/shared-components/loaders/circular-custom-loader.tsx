import {CustomCircularProgress, LoaderWrapper} from '../../../styles/styles.ts';



function CircularCustomLoader() {
  return (
    <LoaderWrapper>
      <CustomCircularProgress />
      </LoaderWrapper>
  );
}

export default CircularCustomLoader;
