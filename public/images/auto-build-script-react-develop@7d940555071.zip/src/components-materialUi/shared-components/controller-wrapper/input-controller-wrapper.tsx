// InputControllerWrapper.tsx
import React from 'react';
import { Controller, Control, FieldValues, RegisterOptions } from 'react-hook-form';
import InputWrapper from '@shared-components/widget-wrapper/input-wrapper';
import { Wrapper, Label, ErrorMessage } from '../../../styles/styles.ts';

interface InputControllerProps {
  formContext?: Control<any>;
  controlName?: string;
  controlId?: string;
  label?: string;
  placeHolder?: string;
  error?: boolean;
  errorMessage?: string;
  controlValidationRules?: Omit<RegisterOptions<FieldValues, string>, "valueAsNumber" | "valueAsDate" | "setValueAs" | "disabled">;
}

const InputControllerWrapper: React.FC<InputControllerProps> = ({
  formContext,
  controlName = '',
  controlId,
  placeHolder,
  label,
  error,
  errorMessage,
  controlValidationRules,
}) => {
  return (
    <Wrapper>
      {label && <Label variant='body2'>{label}</Label>}
      <Controller
        name={controlName}
        control={formContext}
        rules={controlValidationRules}
        render={({ field }) => (
          <InputWrapper
            id={controlId}
            placeholder={placeHolder}
            error={error}
            sx={{
              input: {
                color: 'black',
                width: '100%',
              }
            }}
            {...field}
          />
        )}
      />
      {error && <ErrorMessage variant='body2'>{errorMessage}</ErrorMessage>}
    </Wrapper>
  );
};

export default InputControllerWrapper;
