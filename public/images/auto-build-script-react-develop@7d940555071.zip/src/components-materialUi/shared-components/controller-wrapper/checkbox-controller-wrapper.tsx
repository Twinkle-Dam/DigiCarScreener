// CheckboxControllerWrapper.tsx
import React from 'react';
import { FormControlLabel } from '@mui/material';
import { Controller, Control, FieldValues, RegisterOptions } from 'react-hook-form';
import CheckboxWrapper from '@shared-components/widget-wrapper/checkbox-wrapper';
import { Wrapper, Label, ErrorMessage } from '../../../styles/styles.ts';

interface CheckboxControllerProps {
  formContext?: Control<any>;
  controlName?: string;
  controlId?: string;
  label?: string;
  placeHolder?: string;
  error?: boolean;
  errorMessage?: string;
  controlValidationRules?: Omit<RegisterOptions<FieldValues, string>, "valueAsNumber" | "valueAsDate" | "setValueAs" | "disabled">;
}

const CheckboxControllerWrapper: React.FC<CheckboxControllerProps> = ({
  formContext,
  controlName = '',
  controlId,
  label,
  placeHolder,
  error,
  errorMessage,
  controlValidationRules,
}) => {
  return (
    <Wrapper>
      {label && <Label variant='body2'>{label}</Label>}
      <Controller
        name={controlName}
        control={formContext}
        rules={controlValidationRules}
        render={({ field }) => (
          <FormControlLabel
            label={placeHolder}
            id={controlId}
            {...field}
            control={<CheckboxWrapper />}
          />
        )}
      />
      {error && <ErrorMessage variant='body2'>{errorMessage}</ErrorMessage>}
    </Wrapper>
  );
};

export default CheckboxControllerWrapper;
