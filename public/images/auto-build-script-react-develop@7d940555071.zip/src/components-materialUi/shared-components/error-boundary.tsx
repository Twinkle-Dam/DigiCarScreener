// ErrorBoundary.tsx
import React from 'react';
import useNavigateToTop from '@hooks/useNavigateToTop';
import { SystemText } from './system-fonts/text.tsx';
import { ErrorSection } from '../../styles/styles.ts';
interface ErrorBoundaryProps {
  // You can define any additional props here if needed
}

const ErrorBoundary: React.FC<ErrorBoundaryProps> = () => {
  // const error: unknown | undefined = useRouteError();
  const { goto } = useNavigateToTop();

  return (
    <ErrorSection>
      <SystemText>Something went wrong</SystemText>
      <button onClick={() => goto('/')}>Go back to home</button>
    </ErrorSection>
  );
};

export default ErrorBoundary;
